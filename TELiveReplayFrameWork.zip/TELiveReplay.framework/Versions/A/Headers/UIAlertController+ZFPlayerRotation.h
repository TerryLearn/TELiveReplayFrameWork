

#import <UIKit/UIKit.h>

@interface UIAlertController (ZFPlayerRotation)

@end
