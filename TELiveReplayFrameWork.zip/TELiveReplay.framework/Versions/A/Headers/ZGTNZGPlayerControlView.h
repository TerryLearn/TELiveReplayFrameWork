//
//  ZGPlayerControlView.h
//  TELiveClass
//
//  Created by offcnitc_xt on 2018/2/5.
//  Copyright © 2018年 offcn_c. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZGTNZGPlayerControlView : UIView

/** bottomView*/
@property (nonatomic, strong) UIImageView             *bottomImageView;
/** topView */
@property (nonatomic, strong) UIImageView             *topImageView;

@end
