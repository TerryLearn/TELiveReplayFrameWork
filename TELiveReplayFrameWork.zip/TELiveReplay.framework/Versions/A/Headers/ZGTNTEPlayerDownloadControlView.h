//
//  TEPlayerDownloadControlView.h
//  TELiveClass
//
//  Created by offcnitc_xt on 2017/10/23.
//  Copyright © 2017年 offcn_c. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZGTNTEPlayerDownloadControlView : UIView

@end
