//
//  TEVideoRecordModel.h
//  TELiveClass
//
//  Created by offcnitc_xt on 2017/11/15.
//  Copyright © 2017年 offcn_c. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZGTNTEVideoRecordModel : NSObject

@property (nonatomic, copy) NSString *courseId;
@property (nonatomic, copy) NSString *lessonId;
@property (nonatomic, copy) NSString *recordTime;
@property (nonatomic, copy) NSString *recordStatus;

@end
