//
//  ZGPlayerDownloadControlView.h
//  TELiveClass
//
//  Created by offcnitc_xt on 2018/2/11.
//  Copyright © 2018年 offcn_c. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZGTNZGPlayerDownloadControlView : UIView

@end
