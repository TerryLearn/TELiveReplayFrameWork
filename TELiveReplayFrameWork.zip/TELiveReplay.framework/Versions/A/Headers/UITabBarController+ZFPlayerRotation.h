

#import <UIKit/UIKit.h>

@interface UITabBarController (ZFPlayerRotation)

@end
