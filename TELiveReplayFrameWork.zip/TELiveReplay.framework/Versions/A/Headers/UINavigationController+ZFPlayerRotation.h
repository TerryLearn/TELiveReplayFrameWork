

#import <UIKit/UIKit.h>

@interface UINavigationController (ZFPlayerRotation)<UIGestureRecognizerDelegate>

@end
