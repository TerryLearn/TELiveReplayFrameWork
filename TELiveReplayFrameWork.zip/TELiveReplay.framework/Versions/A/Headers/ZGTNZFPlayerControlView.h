

#import <UIKit/UIKit.h>
#import "ZGTNASValueTrackingSlider.h"
#import "ZFPlayer.h"

@interface ZGTNZFPlayerControlView : UIView 

@end
