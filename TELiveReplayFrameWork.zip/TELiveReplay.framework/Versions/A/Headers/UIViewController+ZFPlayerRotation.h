

#import <UIKit/UIKit.h>

@interface UIViewController (ZFPlayerRotation)

@end
